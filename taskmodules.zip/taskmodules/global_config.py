# 全局配置

# db config
DB_HOST = '192.168.3.12'
DB_PORT = 3306
DB_USERNAME = 'gyl'
DB_PASSWORD = '123456'
DB_DATABASE_GYL = 'nsyy_gyl'
DB_DATABASE_GENERAL = 'nsyy_general'
DB_TABLE_MENU = 'menu'
DB_TABLE_SPORTS_ACTIONS = 'sports_actions'

# DB_HOST = '127.0.0.1'
# DB_PORT = 3306
# DB_USERNAME = 'root'
# DB_PASSWORD = 'gyl.2015'
# DB_DATABASE_GYL = 'nsyy_gyl'


ADDRESS = '127.0.0.1:8080'
# 查询执行中的危机值
QUERY_RUNNING_CVS_URL = f'http://{ADDRESS}/gyl/cv/running_cvs'
# 新建危机值
NEW_CREATE_CV_URL = f'http://{ADDRESS}/gyl/cv/system_create_cv'
# 作废危机值
INVALID_CRISIS_VALUE_URL = f'http://{ADDRESS}/gyl/cv/invalid_cv'
